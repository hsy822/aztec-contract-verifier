#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { program } from 'commander'; 
import { Fr, reduceFn } from '@aztec/foundation/fields';
import { poseidon2HashWithSeparator, poseidon2HashAccumulate, sha256 } from '@aztec/foundation/crypto';
import { FunctionSelector } from './abi/function_selector.mjs';
import { bufferAsFields } from './abi/buffer.mjs';
import { hashVK } from './hash/vk.mjs';
import { computeMerkleRoot } from './util/merkle.mjs';
import { MAX_PACKED_PUBLIC_BYTECODE_SIZE_IN_FIELDS, GeneratorIndex } from '@aztec/constants';
import { loadContractArtifact } from '@aztec/aztec.js';
import { computeArtifactHash } from './hash/artifact_hash.mjs'

program
  .requiredOption('--artifact <path>', 'Path to the compiled contract artifact (.json)')
  .parse(process.argv);

const { artifact: artifactPath } = program.opts();

const sha256Fr = reduceFn(sha256, Fr);

export async function computeClassId(artifact) {
  console.log('\n🔍 Artifact name:', artifact.name);
  console.log('🔍 Total functions:', artifact.functions.length);
  console.log('🔍 outputs keys:', Object.keys(artifact.outputs));
  console.log('🔍 structs:', Object.keys(artifact.outputs.structs));
  console.log('🔍 globals:', Object.keys(artifact.outputs.globals));

  artifact.functions.forEach((fn, idx) => {
    console.log(`  🔸 Function[${idx}]: name="${fn.name}", type="${fn.functionType}", bytecode?=${!!fn.bytecode}, vk?=${!!fn.verificationKey}`);
  });

  // ✅ 1. metadataHash
  const sortedOutputs = {
    structs: Object.keys(artifact.outputs.structs).sort().reduce((acc, key) => {
      acc[key] = artifact.outputs.structs[key];
      return acc;
    }, {}),
    globals: Object.keys(artifact.outputs.globals).sort().reduce((acc, key) => {
      acc[key] = artifact.outputs.globals[key];
      return acc;
    }, {}),
  };
  
  const metadataHash = sha256Fr(
    Buffer.from(JSON.stringify({ name: artifact.name, outputs: sortedOutputs }), 'utf-8'),
  );
  console.log('📦 metadataHash =', metadataHash.toString());

  // ✅ 2. privateFunctionsRoot
  const privateFns = artifact.functions.filter(fn => fn.functionType === 'private');
  const privateFnObjs = await Promise.all(
    privateFns.map(async fn => {
      const selector = await FunctionSelector.fromNameAndParameters(fn.name, fn.parameters ?? []);
      const vkBuf = fn.verificationKey ? Buffer.from(fn.verificationKey, 'base64') : null;
      const vkHash = vkBuf ? await hashVK(vkBuf) : Fr.ZERO;
      console.log(`🔐 private fn = ${fn.name}, selector = ${selector.toString()}, vkHash = ${vkHash.toString()}`);
      return { selector, vkHash };
    }),
  );
  const sortedPrivateFns = privateFnObjs.sort((a, b) => a.selector.toField().cmp(b.selector.toField()));
  const privateLeaves = await Promise.all(
    sortedPrivateFns.map(fn =>
      poseidon2HashWithSeparator([fn.selector.toField(), fn.vkHash], GeneratorIndex.FUNCTION_LEAF),
    ),
  );
  const privateFunctionRoot = await computeMerkleRoot(privateLeaves, GeneratorIndex.FUNCTION_LEAF);
  console.log('🌲 privateFunctionsRoot =', privateFunctionRoot.toString());

  // ✅ 3. utilityFunctionsRoot
  const utilityFns = artifact.functions.filter(fn => fn.functionType === 'utility');
  let utilityFunctionRoot = Fr.ZERO;
  if (utilityFns.length > 0) {
    const utilityFnObjs = await Promise.all(
      utilityFns.map(async fn => {
        const selector = await FunctionSelector.fromNameAndParameters(fn.name, fn.parameters ?? []);
        const vkHash = Fr.ZERO;
        return poseidon2HashWithSeparator([selector.toField(), vkHash], GeneratorIndex.FUNCTION_LEAF);
      }),
    );
    utilityFunctionRoot = await computeMerkleRoot(utilityFnObjs, GeneratorIndex.FUNCTION_LEAF);
  }
  console.log('🧩 utilityFunctionRoot =', utilityFunctionRoot.toString());

  // ✅ 4. artifactHash
  const artifactHash = await computeArtifactHash(artifact)

  console.log('📦 artifactHash =', artifactHash.toString());

  // ✅ 5. public bytecode commitment
  const publicFn = artifact.functions.find(fn => fn.functionType === 'public');
  let publicBytecodeCommitment = Fr.ZERO;
  if (publicFn?.bytecode) {
    const bytecode = Buffer.from(publicFn.bytecode, 'base64');
    const fields = bufferAsFields(bytecode, MAX_PACKED_PUBLIC_BYTECODE_SIZE_IN_FIELDS);
    const byteLength = fields[0].toNumber();
    const chunkSize = Fr.SIZE_IN_BYTES - 1;
    const fieldLen = Math.ceil(byteLength / chunkSize);

    if (fieldLen === 0) {
      publicBytecodeCommitment = Fr.ZERO;
    } else {
      const slice = fields.slice(0, fieldLen + 1);
      console.log(`🧱 publicBytecodeCommitment input fields (${slice.length}):`);
      slice.forEach((f, i) => console.log(`    [${i}] = ${f.toString()}`));
      publicBytecodeCommitment = await poseidon2HashAccumulate(slice);
    }
  }
  console.log('💾 publicBytecodeCommitment =', publicBytecodeCommitment.toString());

  // ✅ 6. classId
  console.log('🔎 classId inputs:');
  console.log('artifactHash             =', artifactHash.toString());
  console.log('privateFunctionRoot      =', privateFunctionRoot.toString());
  console.log('publicBytecodeCommitment =', publicBytecodeCommitment.toString());

  const classId = await poseidon2HashWithSeparator(
    [artifactHash, privateFunctionRoot, publicBytecodeCommitment],
    GeneratorIndex.CONTRACT_LEAF,
  );

  console.log('✅ FINAL classId =', classId.toString());
  return classId;
}

(async () => {
  try {
    const fullPath = path.resolve(artifactPath);
    const rawJson = JSON.parse(fs.readFileSync(fullPath, 'utf-8'));
    const artifact = loadContractArtifact(rawJson); // 공식 방식
    const classId = await computeClassId(artifact);
    console.log(`\n✅ Computed Contract Class ID: ${classId.toString()}`);
  } catch (err) {
    console.error('❌ Error computing class ID:', err);
    process.exit(1);
  }
})();
